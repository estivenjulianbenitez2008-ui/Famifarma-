// Año automático y pequeño efecto de movimiento del logotipo.
document.getElementById('year').textContent = new Date().getFullYear();

const logo = document.querySelector('.hero-logo');
const stage = document.querySelector('.logo-stage');

if (logo && stage && window.matchMedia('(pointer: fine)').matches) {
  stage.addEventListener('pointermove', (event) => {
    const rect = stage.getBoundingClientRect();
    const x = (event.clientX - rect.left - rect.width / 2) / 18;
    const y = (event.clientY - rect.top - rect.height / 2) / 18;
    logo.style.translate = `${x}px ${y}px`;
  });
  stage.addEventListener('pointerleave', () => {
    logo.style.translate = '0 0';
  });
}
